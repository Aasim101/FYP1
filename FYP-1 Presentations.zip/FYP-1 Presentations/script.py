import os
import shutil

# Directory paths
dataset_dir = "/media/fast/New Volume/FAST/FYP/Brats2020 Nifti format for DeepMedic/archive/BraTS2020_TrainingData/MICCAI_BraTS2020_TrainingData"
nnunet_dir = "/home/fast/nnUNet/nnUNet_raw_data_base/nnUNet_raw_data/Task01_BRATS"

# Ensure nnUNet directories exist
os.makedirs(os.path.join(nnunet_dir, "imagesTr"), exist_ok=True)
os.makedirs(os.path.join(nnunet_dir, "labelsTr"), exist_ok=True)

# Copy files
for dir_name in os.listdir(dataset_dir):
    if dir_name.startswith("BraTS20_Training_"):
        dir_path = os.path.join(dataset_dir, dir_name)
        patient_id = dir_name

        # Define file paths
        modalities = {
            "t1": "0000",
            "t1ce": "0001",
            "t2": "0002",
            "flair": "0003"
        }

        # Copy modality files
        for modality, suffix in modalities.items():
            src_file = os.path.join(dir_path, f"{patient_id}_{modality}.nii")
            dest_file = os.path.join(nnunet_dir, "imagesTr", f"{patient_id}_{suffix}.nii")
            if os.path.exists(src_file):
                shutil.copy(src_file, dest_file)

        # Copy segmentation file
        seg_src = os.path.join(dir_path, f"{patient_id}_seg.nii")
        seg_dest = os.path.join(nnunet_dir, "labelsTr", f"{patient_id}.nii")
        if os.path.exists(seg_src):
            shutil.copy(seg_src, seg_dest)

print("All files copied successfully in .nii format!")

